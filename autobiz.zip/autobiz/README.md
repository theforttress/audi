# AutoBiz
WhatsApp AI auto-reply, orders and payments for Nigerian businesses.

    autobiz/
      supabase/schema.sql   run once in the Supabase SQL editor
      backend/              Express: WhatsApp + Paystack webhooks, AI, jobs, /api/send, /api/admin/businesses  -> Railway
      web/                  Next.js dashboards (business + /admin)                                         -> Vercel

## First-time setup
1. Run `supabase/schema.sql`. Enable Realtime on `messages`.
2. Supabase Auth: create your user, then insert into `profiles` (id, email, role='super_admin').
3. `cp backend/.env.example backend/.env` and `cp web/.env.local.example web/.env.local`; fill both.
4. `npm install`, then `npm run backend` and `npm run web:dev`.
5. Log in at /login -> /admin -> "+ Add business" (creates business, encrypted token, owner login).

## Deploy
- Railway: root directory `backend`, start `npm start`; set backend env vars + `FRONTEND_URL`.
- Vercel: root directory `web`; set the 3 `NEXT_PUBLIC_*` vars.
- Meta webhook: `https://<railway-url>/api/whatsapp/webhook`, verify token = `WA_VERIFY_TOKEN`, subscribe to `messages`.
- Paystack webhook: `https://<railway-url>/api/paystack/webhook`.

## Not built yet
Broadcasts, Twilio calls, Paystack subscription billing, customers/bookings pages, reports.
