create extension if not exists pgcrypto;
create table businesses(id uuid primary key default gen_random_uuid(), name text not null, owner_name text, phone text,
 whatsapp_phone_id text unique, whatsapp_token_enc text, paystack_subaccount text, business_type text default 'food',
 price_list jsonb default '[]', ai_instructions text, ai_tone text default 'friendly', working_hours text, auto_reply boolean default true,
 subscription_status text default 'trial', subscription_plan text, next_payment_date date, created_at timestamptz default now());
create table profiles(id uuid primary key references auth.users, email text, role text default 'business_owner', business_id uuid references businesses);
create table customers(id uuid primary key default gen_random_uuid(), business_id uuid references businesses not null, name text, phone text not null, email text, tags text[], last_message_at timestamptz, unique(business_id,phone));
create table conversations(id uuid primary key default gen_random_uuid(), business_id uuid references businesses not null, customer_id uuid references customers not null, status text default 'ai', assigned_to uuid, created_at timestamptz default now());
create table messages(id uuid primary key default gen_random_uuid(), conversation_id uuid references conversations not null, business_id uuid references businesses not null, sender text not null, text text, media_url text, wa_message_id text unique, created_at timestamptz default now());
create table orders(id uuid primary key default gen_random_uuid(), business_id uuid references businesses not null, customer_id uuid references customers not null, items jsonb, total numeric, status text default 'pending', address text, payment_link text, payment_ref text unique, reminded boolean default false, created_at timestamptz default now());
create table bookings(id uuid primary key default gen_random_uuid(), business_id uuid references businesses not null, customer_id uuid references customers not null, service text, date date, time text, status text default 'pending');
create table broadcasts(id uuid primary key default gen_random_uuid(), business_id uuid references businesses not null, message text, sent_count int default 0, created_at timestamptz default now());
create table calls(id uuid primary key default gen_random_uuid(), business_id uuid references businesses not null, customer_id uuid references customers, customer_phone text, call_status text, recording_url text, summary text, created_at timestamptz default now());
create table subscriptions(id uuid primary key default gen_random_uuid(), business_id uuid references businesses not null, plan text, amount numeric, next_payment_date date, paystack_customer_code text);

create function is_super() returns boolean language sql stable security definer as $$ select exists(select 1 from profiles where id=auth.uid() and role='super_admin') $$;
create function my_business() returns uuid language sql stable security definer as $$ select business_id from profiles where id=auth.uid() $$;

do $$ declare t text; begin
 foreach t in array array['customers','conversations','messages','orders','bookings','broadcasts','calls','subscriptions'] loop
  execute format('alter table %I enable row level security',t);
  execute format('create policy "tenant" on %I for all using (is_super() or business_id=my_business()) with check (is_super() or business_id=my_business())',t);
 end loop; end $$;
alter table businesses enable row level security;
create policy "own business read" on businesses for select using (is_super() or id=my_business());
create policy "own business update" on businesses for update using (is_super() or id=my_business());
alter table profiles enable row level security;
create policy "own profile" on profiles for select using (id=auth.uid() or is_super());
-- Owners must not read whatsapp_token_enc from the browser:
revoke select(whatsapp_token_enc) on businesses from authenticated, anon;
