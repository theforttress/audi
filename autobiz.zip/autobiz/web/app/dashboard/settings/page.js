'use client';
import { useEffect, useState } from 'react';
import { sb, ctx } from '@/lib/supabase';
export default function Settings() {
  const [b, setB] = useState(null); const [ok, setOk] = useState(false);
  useEffect(() => { ctx().then(async c => { const { data } = await sb.from('businesses').select('id,name,ai_tone,working_hours,auto_reply,ai_instructions').eq('id', c.profile.business_id).single(); setB(data); }); }, []);
  if (!b) return <p>Super admin: open a business account to edit its settings.</p>;
  const set = (k, v) => setB({ ...b, [k]: v });
  const save = async () => { const { id, ...rest } = b; await sb.from('businesses').update(rest).eq('id', id); setOk(true); setTimeout(() => setOk(false), 1500); };
  const F = 'w-full border p-2 rounded';
  return (<div className="max-w-xl space-y-3 bg-white p-4 rounded-xl shadow">
    <label>Business name<input className={F} value={b.name || ''} onChange={e => set('name', e.target.value)} /></label>
    <label>AI tone<select className={F} value={b.ai_tone} onChange={e => set('ai_tone', e.target.value)}><option value="formal">Formal</option><option value="pidgin">Pidgin</option><option value="friendly">Friendly</option></select></label>
    <label>Working hours<input className={F} value={b.working_hours || ''} onChange={e => set('working_hours', e.target.value)} /></label>
    <label>Extra AI instructions<textarea className={F} rows={4} value={b.ai_instructions || ''} onChange={e => set('ai_instructions', e.target.value)} /></label>
    <label className="flex gap-2"><input type="checkbox" checked={b.auto_reply} onChange={e => set('auto_reply', e.target.checked)} />Auto-reply ON</label>
    <button onClick={save} className="bg-green-600 text-white px-4 py-2 rounded">Save</button>{ok && <span className="ml-2 text-green-600">Saved</span>}</div>);
}
