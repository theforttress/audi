'use client';
import { useEffect, useState } from 'react';
import { sb, API } from '@/lib/supabase';
export default function Chats() {
  const [convs, setConvs] = useState([]); const [sel, setSel] = useState(null); const [msgs, setMsgs] = useState([]); const [text, setText] = useState('');
  const load = async () => { const { data } = await sb.from('conversations').select('*, customers(name,phone), businesses(name)').order('created_at', { ascending: false }); setConvs(data || []); };
  useEffect(() => { load(); }, []);
  useEffect(() => {
    if (!sel) return;
    const f = async () => { const { data } = await sb.from('messages').select('*').eq('conversation_id', sel.id).order('created_at'); setMsgs(data || []); };
    f();
    const ch = sb.channel('m' + sel.id).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${sel.id}` }, f).subscribe();
    return () => { sb.removeChannel(ch); };
  }, [sel?.id]);
  const setStatus = async s => { await sb.from('conversations').update({ status: s }).eq('id', sel.id); setSel({ ...sel, status: s }); load(); };
  const send = async () => {
    if (!text.trim()) return;
    if (sel.status === 'ai') await setStatus('human');
    const { data: { session } } = await sb.auth.getSession();
    await fetch(`${API}/api/send`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` }, body: JSON.stringify({ conversation_id: sel.id, text }) });
    setText('');
  };
  return (<div className="grid md:grid-cols-3 gap-3 h-[80vh]">
    <div className={`bg-white rounded-xl shadow overflow-y-auto ${sel ? 'hidden md:block' : ''}`}>
      {convs.map(c => <button key={c.id} onClick={() => setSel(c)} className={`w-full text-left p-3 border-b hover:bg-green-50 ${sel?.id === c.id ? 'bg-green-50' : ''}`}>
        <p className="font-medium">{c.customers?.name || c.customers?.phone}</p>
        <p className="text-xs text-gray-500">{c.businesses?.name} · {c.status === 'ai' ? '🤖 AI' : c.status === 'human' ? '🙋 Human' : 'Closed'}</p></button>)}
    </div>
    <div className={`md:col-span-2 bg-white rounded-xl shadow flex flex-col ${sel ? '' : 'hidden md:flex'}`}>
      {!sel ? <p className="m-auto text-gray-400">Select a chat</p> : <>
        <div className="p-3 border-b flex items-center gap-2">
          <button className="md:hidden" onClick={() => setSel(null)}>←</button>
          <b className="flex-1">{sel.customers?.name || sel.customers?.phone}</b>
          {sel.status === 'ai'
            ? <button onClick={() => setStatus('human')} className="bg-orange-500 text-white px-3 py-1 rounded">Take Over</button>
            : <button onClick={() => setStatus('ai')} className="bg-green-600 text-white px-3 py-1 rounded">Give to AI</button>}
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {msgs.map(m => <div key={m.id} className={`max-w-[80%] p-2 rounded-lg text-sm ${m.sender === 'customer' ? 'bg-gray-100' : 'bg-green-100 ml-auto'}`}>
            <p className="text-[10px] text-gray-500">{m.sender}</p>{m.text}</div>)}
        </div>
        <div className="p-3 border-t flex gap-2"><input className="flex-1 border p-2 rounded" value={text} onChange={e => setText(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Type a reply (pauses AI)" />
          <button onClick={send} className="bg-green-600 text-white px-4 rounded">Send</button></div></>}
    </div></div>);
}
