'use client';
import { useEffect, useState } from 'react';
import { sb } from '@/lib/supabase';
export default function Home() {
  const [s, setS] = useState({});
  useEffect(() => { (async () => {
    const d = new Date(); d.setHours(0, 0, 0, 0); const t = d.toISOString();
    const [m, o, p] = await Promise.all([
      sb.from('messages').select('id', { count: 'exact', head: true }).gte('created_at', t),
      sb.from('orders').select('id', { count: 'exact', head: true }).gte('created_at', t),
      sb.from('orders').select('total').eq('status', 'paid').gte('created_at', t)]);
    setS({ m: m.count, o: o.count, sales: (p.data || []).reduce((a, x) => a + Number(x.total), 0) }); })(); }, []);
  const Card = ({ t, v }) => <div className="bg-white p-4 rounded-xl shadow"><p className="text-sm text-gray-500">{t}</p><p className="text-2xl font-bold">{v ?? '…'}</p></div>;
  return <div className="grid grid-cols-1 sm:grid-cols-3 gap-3"><Card t="Messages today" v={s.m} /><Card t="Orders today" v={s.o} /><Card t="Paid sales today" v={s.sales != null ? '₦' + s.sales.toLocaleString() : null} /></div>;
}
