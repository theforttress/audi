'use client';
import { useEffect, useState } from 'react';
import { sb } from '@/lib/supabase';
const cols = ['pending', 'paid', 'delivered', 'cancelled'];
export default function Orders() {
  const [o, setO] = useState([]);
  const load = async () => { const { data } = await sb.from('orders').select('*, customers(name,phone)').order('created_at', { ascending: false }); setO(data || []); };
  useEffect(() => { load(); }, []);
  const move = async (id, status) => { await sb.from('orders').update({ status }).eq('id', id); load(); };
  return (<div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">{cols.map(c => <div key={c}>
    <h2 className="font-bold capitalize mb-2">{c} ({o.filter(x => x.status === c).length})</h2>
    <div className="space-y-2">{o.filter(x => x.status === c).map(x => <div key={x.id} className="bg-white p-3 rounded-xl shadow text-sm">
      <p className="font-medium">{x.customers?.name || x.customers?.phone}</p>
      <p>{(x.items || []).map(i => `${i.qty}× ${i.name}`).join(', ')}</p>
      <p className="font-bold">₦{Number(x.total).toLocaleString()}</p>{x.address && <p className="text-gray-500">{x.address}</p>}
      <select value={x.status} onChange={e => move(x.id, e.target.value)} className="mt-2 border rounded p-1 w-full">{cols.map(s => <option key={s}>{s}</option>)}</select>
    </div>)}</div></div>)}</div>);
}
