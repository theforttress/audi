'use client';
import { useEffect, useState } from 'react';
import { sb, ctx } from '@/lib/supabase';
export default function PriceList() {
  const [biz, setBiz] = useState(null); const [items, setItems] = useState([]); const [name, setName] = useState(''); const [price, setPrice] = useState(''); const [saved, setSaved] = useState(false);
  useEffect(() => { ctx().then(async c => { const { data } = await sb.from('businesses').select('id,price_list').eq('id', c.profile.business_id).single(); setBiz(data); setItems(data?.price_list || []); }); }, []);
  const save = async (list) => { setItems(list); await sb.from('businesses').update({ price_list: list }).eq('id', biz.id); setSaved(true); setTimeout(() => setSaved(false), 1500); };
  if (!biz) return <p>Super admin: open a business account to edit its price list.</p>;
  return (<div className="max-w-xl space-y-3">
    <div className="flex gap-2"><input className="flex-1 border p-2 rounded" placeholder="Product" value={name} onChange={e => setName(e.target.value)} />
      <input className="w-28 border p-2 rounded" type="number" placeholder="₦ Price" value={price} onChange={e => setPrice(e.target.value)} />
      <button className="bg-green-600 text-white px-4 rounded" onClick={() => { if (name && price) { save([...items, { name, price: Number(price) }]); setName(''); setPrice(''); } }}>Add</button></div>
    {saved && <p className="text-green-600 text-sm">Saved. The AI uses it immediately.</p>}
    {items.map((i, n) => <div key={n} className="bg-white p-3 rounded-xl shadow flex"><span className="flex-1">{i.name}</span><b className="mr-3">₦{i.price.toLocaleString()}</b>
      <button className="text-red-600" onClick={() => save(items.filter((_, k) => k !== n))}>Remove</button></div>)}</div>);
}
