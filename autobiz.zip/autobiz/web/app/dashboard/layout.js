'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { sb, ctx } from '@/lib/supabase';
const links = [['', 'Home'], ['/chats', 'Chats'], ['/orders', 'Orders'], ['/pricelist', 'Price List'], ['/settings', 'Settings']];
export default function Layout({ children }) {
  const [c, setC] = useState(null); const r = useRouter();
  useEffect(() => { ctx().then(x => x ? setC(x) : r.push('/login')); }, []);
  if (!c) return <p className="p-6">Loading…</p>;
  return (<div className="min-h-screen md:flex">
    <nav className="bg-white border-b md:border-r md:w-48 flex md:flex-col gap-1 p-2 overflow-x-auto">
      {links.map(([h, t]) => <Link key={t} href={'/dashboard' + h} className="px-3 py-2 rounded hover:bg-green-50 whitespace-nowrap">{t}</Link>)}
      {c.profile?.role === 'super_admin' && <Link href="/admin" className="px-3 py-2 rounded bg-yellow-50 whitespace-nowrap">Admin</Link>}
      <button onClick={async () => { await sb.auth.signOut(); r.push('/login'); }} className="px-3 py-2 text-left text-red-600">Log out</button>
    </nav><main className="flex-1 p-4">{children}</main></div>);
}
