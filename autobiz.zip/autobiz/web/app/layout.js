import './globals.css';
export const metadata = { title: 'AutoBiz' };
export default function Root({ children }) {
  return <html lang="en"><body className="bg-gray-50 text-gray-900">{children}</body></html>;
}
