'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { sb, ctx } from '@/lib/supabase';
export default function Admin() {
  const [biz, setBiz] = useState([]); const [s, setS] = useState({}); const r = useRouter();
  const load = async () => {
    const d = new Date(); d.setHours(0, 0, 0, 0); const t = d.toISOString();
    const [b, m, o] = await Promise.all([sb.from('businesses').select('id,name,owner_name,phone,subscription_plan,subscription_status,next_payment_date'),
      sb.from('messages').select('id', { count: 'exact', head: true }).gte('created_at', t), sb.from('orders').select('id', { count: 'exact', head: true }).gte('created_at', t)]);
    setBiz(b.data || []); setS({ m: m.count, o: o.count });
  };
  useEffect(() => { ctx().then(c => { if (c?.profile?.role !== 'super_admin') r.push('/dashboard'); else load(); }); }, []);
  const setStatus = async (id, subscription_status) => { await sb.from('businesses').update({ subscription_status }).eq('id', id); load(); };
  const Card = ({ t, v }) => <div className="bg-white p-4 rounded-xl shadow"><p className="text-sm text-gray-500">{t}</p><p className="text-2xl font-bold">{v ?? '…'}</p></div>;
  return (<div className="p-4 space-y-4"><div className="flex"><h1 className="text-xl font-bold flex-1">Super Admin</h1><Link href="/admin/new" className="text-green-700 mr-4">+ Add business</Link><Link href="/dashboard/chats" className="text-green-700">All chats →</Link></div>
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3"><Card t="Businesses" v={biz.length} /><Card t="Active" v={biz.filter(b => b.subscription_status === 'active').length} />
      <Card t="Messages today" v={s.m} /><Card t="Orders today" v={s.o} /></div>
    <div className="bg-white rounded-xl shadow overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left border-b"><th className="p-2">Business</th><th>Plan</th><th>Next payment</th><th>Status</th></tr></thead>
      <tbody>{biz.map(b => <tr key={b.id} className="border-b"><td className="p-2">{b.name}<br /><span className="text-gray-500">{b.owner_name} {b.phone}</span></td><td>{b.subscription_plan}</td><td>{b.next_payment_date}</td>
        <td><select value={b.subscription_status} onChange={e => setStatus(b.id, e.target.value)} className="border rounded p-1"><option>trial</option><option>active</option><option>expired</option></select></td></tr>)}</tbody></table></div></div>);
}
