'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { sb, API } from '@/lib/supabase';
const fields = [['name', 'Business name'], ['owner_name', 'Owner name'], ['phone', 'Owner phone'], ['owner_email', 'Owner login email'], ['password', 'Temporary password'],
  ['whatsapp_phone_id', 'WhatsApp Phone Number ID'], ['whatsapp_token', 'WhatsApp access token'], ['paystack_subaccount', 'Paystack subaccount code'], ['plan', 'Plan (e.g. 20k)']];
export default function NewBusiness() {
  const [f, setF] = useState({ business_type: 'food' }); const [msg, setMsg] = useState(''); const r = useRouter();
  const submit = async () => {
    const { data: { session } } = await sb.auth.getSession();
    const res = await fetch(`${API}/api/admin/businesses`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` }, body: JSON.stringify(f) });
    const j = await res.json().catch(() => ({}));
    res.ok ? r.push('/admin') : setMsg(j.error || 'Failed');
  };
  return (<div className="max-w-md mx-auto p-4 space-y-3"><h1 className="text-xl font-bold">Add business</h1>
    {fields.map(([k, l]) => <input key={k} className="w-full border p-2 rounded" placeholder={l} type={k === 'password' ? 'password' : 'text'} onChange={e => setF({ ...f, [k]: e.target.value })} />)}
    <select className="w-full border p-2 rounded" onChange={e => setF({ ...f, business_type: e.target.value })}>{['food', 'tailor', 'salon', 'school', 'clinic'].map(t => <option key={t}>{t}</option>)}</select>
    {msg && <p className="text-red-600 text-sm">{msg}</p>}<button onClick={submit} className="w-full bg-green-600 text-white p-2 rounded">Create (7-day trial)</button></div>);
}
