'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { sb } from '@/lib/supabase';
export default function Login() {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [err, setErr] = useState(''); const r = useRouter();
  const go = async () => { const { error } = await sb.auth.signInWithPassword({ email, password }); error ? setErr(error.message) : r.push('/dashboard'); };
  return (<div className="min-h-screen grid place-items-center p-4"><div className="w-full max-w-sm bg-white p-6 rounded-xl shadow space-y-3">
    <h1 className="text-xl font-bold">AutoBiz</h1>
    <input className="w-full border p-2 rounded" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
    <input className="w-full border p-2 rounded" type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
    {err && <p className="text-red-600 text-sm">{err}</p>}
    <button onClick={go} className="w-full bg-green-600 text-white p-2 rounded">Log in</button></div></div>);
}
