import 'dotenv/config';
import express from 'express';
import crypto from 'crypto';
import { db, encrypt } from './db.js';
import { think, priceItems } from './ai.js';
import { saveAndSend } from './whatsapp.js';
import { createLink, paystackWebhook } from './paystack.js';
import { startJobs } from './jobs.js';
const app = express();
const raw = express.raw({ type: '*/*' });
app.use((req, res, next) => { res.set({ 'Access-Control-Allow-Origin': process.env.FRONTEND_URL || '*', 'Access-Control-Allow-Headers': 'Authorization,Content-Type' });
  req.method === 'OPTIONS' ? res.sendStatus(204) : next(); });

app.get('/api/whatsapp/webhook', (req, res) =>
  req.query['hub.verify_token'] === process.env.WA_VERIFY_TOKEN ? res.send(req.query['hub.challenge']) : res.sendStatus(403));

app.post('/api/whatsapp/webhook', raw, (req, res) => {
  const sig = 'sha256=' + crypto.createHmac('sha256', process.env.META_APP_SECRET).update(req.body).digest('hex');
  const given = req.headers['x-hub-signature-256'] || '';
  if (given.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(given))) return res.sendStatus(401);
  res.sendStatus(200); // ack fast, process async so Meta doesn't retry
  const body = JSON.parse(req.body);
  for (const e of body.entry || []) for (const c of e.changes || [])
    handle(c.value).catch(err => console.error('handle error', err));
});
app.post('/api/paystack/webhook', raw, paystackWebhook);

async function handle(v) {
  if (!v.messages) return;
  const { data: business } = await db.from('businesses').select('*').eq('whatsapp_phone_id', v.metadata.phone_number_id).single();
  if (!business) return;
  for (const m of v.messages) {
    if (m.type !== 'text') continue;
    const phone = m.from;
    const { data: customer } = await db.from('customers').upsert({ business_id: business.id, phone, name: v.contacts?.[0]?.profile?.name, last_message_at: new Date() }, { onConflict: 'business_id,phone' }).select().single();
    let { data: conv } = await db.from('conversations').select('*').eq('customer_id', customer.id).neq('status', 'closed').limit(1).maybeSingle();
    if (!conv) ({ data: conv } = await db.from('conversations').insert({ business_id: business.id, customer_id: customer.id }).select().single());
    const { error } = await db.from('messages').insert({ conversation_id: conv.id, business_id: business.id, sender: 'customer', text: m.text.body, wa_message_id: m.id });
    if (error?.code === '23505') continue; // duplicate delivery
    if (['expired'].includes(business.subscription_status) || !business.auto_reply || conv.status === 'human') continue;
    const { data: rows } = await db.from('messages').select('sender,text').eq('conversation_id', conv.id).order('created_at', { ascending: false }).limit(11);
    const history = rows.reverse().slice(0, -1).map(r => ({ role: r.sender === 'customer' ? 'user' : 'assistant', content: r.text || '' }));
    const out = await think(business, history, m.text.body);
    let reply = out.reply;
    if (out.action === 'need_human') await db.from('conversations').update({ status: 'human' }).eq('id', conv.id);
    if (out.action === 'create_order') {
      const priced = priceItems(business.price_list, out.items);
      if (!priced) reply = 'Abeg confirm the items you want from our price list, I no fit find some of them.';
      else {
        const { data: order } = await db.from('orders').insert({ business_id: business.id, customer_id: customer.id, items: priced.lines, total: priced.total, address: out.address }).select().single();
        const link = await createLink(business, customer, order);
        await db.from('orders').update({ payment_link: link }).eq('id', order.id);
        reply = `${out.reply}\nTotal: ₦${priced.total.toLocaleString()}\nPay here: ${link}`;
      }
    }
    if (out.action === 'create_booking') {
      const clash = out.date && await db.from('bookings').select('id').eq('business_id', business.id).eq('date', out.date).eq('time', out.time).neq('status', 'cancelled').limit(1);
      if (clash?.data?.length) reply = 'That time don don book. Abeg pick another time.';
      else await db.from('bookings').insert({ business_id: business.id, customer_id: customer.id, service: out.service, date: out.date, time: out.time });
    }
    await saveAndSend(business, conv, customer, 'ai', reply);
  }
}
// Dashboard replies: owner or super admin sends a manual message
app.post('/api/send', express.json(), async (req, res) => {
  const { data: { user } } = await db.auth.getUser((req.headers.authorization || '').replace('Bearer ', ''));
  if (!user) return res.sendStatus(401);
  const { data: p } = await db.from('profiles').select('*').eq('id', user.id).single();
  const { data: conv } = await db.from('conversations').select('*, customers(*), businesses(*)').eq('id', req.body.conversation_id).single();
  if (!conv || !p || (p.role !== 'super_admin' && conv.business_id !== p.business_id)) return res.sendStatus(403);
  await saveAndSend(conv.businesses, conv, conv.customers, p.role === 'super_admin' ? 'super_admin' : 'owner', req.body.text);
  res.sendStatus(200);
});
// Super admin: onboard a business in one step (business row + owner login + profile)
app.post('/api/admin/businesses', express.json(), async (req, res) => {
  const { data: { user } } = await db.auth.getUser((req.headers.authorization || '').replace('Bearer ', ''));
  if (!user) return res.sendStatus(401);
  const { data: me } = await db.from('profiles').select('role').eq('id', user.id).single();
  if (me?.role !== 'super_admin') return res.sendStatus(403);
  const b = req.body;
  if (!b.name || !b.owner_email || !b.password) return res.status(400).json({ error: 'name, owner_email, password required' });
  const { data: biz, error } = await db.from('businesses').insert({ name: b.name, owner_name: b.owner_name, phone: b.phone, business_type: b.business_type || 'food',
    whatsapp_phone_id: b.whatsapp_phone_id || null, whatsapp_token_enc: b.whatsapp_token ? encrypt(b.whatsapp_token) : null, paystack_subaccount: b.paystack_subaccount || null,
    subscription_plan: b.plan, subscription_status: 'trial', next_payment_date: new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10) }).select().single();
  if (error) return res.status(400).json({ error: error.message });
  const { data: u, error: ue } = await db.auth.admin.createUser({ email: b.owner_email, password: b.password, email_confirm: true });
  if (ue) { await db.from('businesses').delete().eq('id', biz.id); return res.status(400).json({ error: ue.message }); }
  await db.from('profiles').insert({ id: u.user.id, email: b.owner_email, role: 'business_owner', business_id: biz.id });
  res.json({ business_id: biz.id });
});
app.get('/health', (_, res) => res.send('ok'));
app.listen(process.env.PORT || 3000, () => { console.log('AutoBiz up'); startJobs(); });
