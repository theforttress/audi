import { db } from './db.js';
import { sendText } from './whatsapp.js';
export function startJobs() {
  setInterval(async () => {
    try {
      const cutoff = new Date(Date.now() - 2 * 3600e3).toISOString();
      const { data: orders } = await db.from('orders').select('*, customers(phone,name), businesses(*)').eq('status', 'pending').eq('reminded', false).lt('created_at', cutoff);
      for (const o of orders || []) {
        // Works only inside Meta's 24h window; use an approved template beyond it.
        await sendText(o.businesses, o.customers.phone, `Hello ${o.customers.name || ''}, your order still dey wait. Pay here: ${o.payment_link}`);
        await db.from('orders').update({ reminded: true }).eq('id', o.id);
      }
      await db.from('businesses').update({ subscription_status: 'expired' }).lt('next_payment_date', new Date().toISOString().slice(0, 10)).neq('subscription_status', 'expired');
    } catch (e) { console.error('job error', e); }
  }, 10 * 60e3);
}
