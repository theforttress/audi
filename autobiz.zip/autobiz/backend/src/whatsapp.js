import { db, decrypt } from './db.js';
export async function sendText(business, to, text) {
  const r = await fetch(`https://graph.facebook.com/v21.0/${business.whatsapp_phone_id}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${decrypt(business.whatsapp_token_enc)}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messaging_product: 'whatsapp', to, type: 'text', text: { body: text } }) });
  if (!r.ok) console.error('WA send failed', r.status, await r.text());
  return r.ok;
}
export async function saveAndSend(business, conv, customer, sender, text) {
  await db.from('messages').insert({ conversation_id: conv.id, business_id: business.id, sender, text });
  return sendText(business, customer.phone, text);
}
