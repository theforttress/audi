import crypto from 'crypto';
import { db } from './db.js';
import { saveAndSend } from './whatsapp.js';
export async function createLink(business, customer, order) {
  const body = { email: customer.email || `${customer.phone}@autobiz.ng`, amount: Math.round(order.total * 100), reference: order.id,
    metadata: { order_id: order.id, business_id: business.id } };
  if (business.paystack_subaccount) { body.subaccount = business.paystack_subaccount; body.transaction_charge = Math.round(order.total * 100 * 0.02); }
  const r = await fetch('https://api.paystack.co/transaction/initialize', { method: 'POST',
    headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const j = await r.json(); return j.status ? j.data.authorization_url : null;
}
export async function paystackWebhook(req, res) {
  const sig = crypto.createHmac('sha512', process.env.PAYSTACK_SECRET).update(req.body).digest('hex');
  if (sig !== req.headers['x-paystack-signature']) return res.sendStatus(401);
  res.sendStatus(200);
  const ev = JSON.parse(req.body);
  if (ev.event !== 'charge.success') return;
  const { data: order } = await db.from('orders').update({ status: 'paid', payment_ref: ev.data.reference }).eq('id', ev.data.metadata?.order_id).eq('status', 'pending').select().single();
  if (!order) return; // already processed or unknown
  const [{ data: business }, { data: customer }] = await Promise.all([db.from('businesses').select('*').eq('id', order.business_id).single(), db.from('customers').select('*').eq('id', order.customer_id).single()]);
  const { data: conv } = await db.from('conversations').select('*').eq('customer_id', customer.id).order('created_at', { ascending: false }).limit(1).single();
  await saveAndSend(business, conv, customer, 'ai', 'Payment received. Thank you! Your order dey on the way.');
}
