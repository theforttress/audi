import OpenAI from 'openai';
const openai = new OpenAI();
const extras = {
  food: 'Ask for delivery address and whether they want a drink.',
  tailor: 'Ask for measurements, style picture, and delivery date.',
  salon: 'Ask for service, date and time.',
  school: 'Ask for child name, class and parent phone.',
  clinic: 'Ask for symptoms and book an appointment. Never diagnose.' };
export async function think(business, history, text) {
  const sys = `You are the assistant for ${business.name} (${business.business_type}). Tone: ${business.ai_tone}, short, Nigerian style.
Working hours: ${business.working_hours || 'not set'}. Price list (name, price in NGN): ${JSON.stringify(business.price_list)}.
${extras[business.business_type] || ''} ${business.ai_instructions || ''}
For orders/bookings collect name, what they want, date/address. Never invent prices or delivery times. If unsure say "Make I confirm with Oga" and use action need_human.
Reply ONLY JSON: {"reply":string,"action":"none"|"create_order"|"create_booking"|"need_human",
"items":[{"name":string,"qty":number}],"customer_name":string|null,"address":string|null,"service":string|null,"date":"YYYY-MM-DD"|null,"time":string|null}.
Use create_order only when the customer has confirmed the items. Do not state totals; the system adds them.`;
  const r = await openai.chat.completions.create({ model: 'gpt-4o-mini', response_format: { type: 'json_object' }, temperature: 0.3,
    messages: [{ role: 'system', content: sys }, ...history, { role: 'user', content: text }] });
  try { return JSON.parse(r.choices[0].message.content); }
  catch { return { reply: 'Make I confirm with Oga.', action: 'need_human' }; }
}
// Totals are computed in code, never by the model.
export function priceItems(priceList, items = []) {
  const lines = []; let total = 0;
  for (const i of items) {
    const p = priceList.find(x => x.name.toLowerCase() === String(i.name).toLowerCase());
    if (!p) return null;
    const qty = Math.max(1, Math.floor(i.qty || 1)); total += p.price * qty; lines.push({ name: p.name, qty, price: p.price });
  }
  return lines.length ? { lines, total } : null;
}
